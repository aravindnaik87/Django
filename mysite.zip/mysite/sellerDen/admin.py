from django.contrib import admin

from .models import Clothing_Details
# Register your models here.

admin.site.register(Clothing_Details)