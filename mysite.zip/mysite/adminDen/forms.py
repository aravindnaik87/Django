from .models import BrandsModel
from django.forms import ModelForm
from django import forms

class BrandsModelForm(ModelForm):
    class Meta:
        model = BrandsModel
        fields = '__all__'