from django.apps import AppConfig


class AdmindenConfig(AppConfig):
    name = 'adminDen'
