from django.db import models

# Create your models here.

class Address(models.Model):
    customer_id = models.CharField(max_length=20)
    address_label = models.CharField(max_length=20)
    address_description = models.CharField(max_length=300)
    address_pincode = models.CharField(max_length=10)
    address_disctrict = models.CharField(max_length=100)
    address_state = models.CharField(max_length=100)
    address_default = models.BooleanField(default=False)

    def __Str__(self):
        return self.address_label