from django.contrib import admin
from .models import BrandsModel

# Register your models here.

admin.site.register(BrandsModel)