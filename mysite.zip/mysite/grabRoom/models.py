from django.db import models

# Create your models here.

class MeetingRoom(models.Model):
    room_name = models.CharField(max_length=50)
    room_capacity = models.IntegerField(default=4)
    room_is_conference = models.BooleanField(default=False)

    class Meta:
        abstract = True

    def __str__(self):
        return self.room_name

class DetailedEvent(MeetingRoom):
    event_title = models.CharField(max_length=100)
    event_description = models.CharField(max_length=300)
    event_date = models.DateField()
    event_start_time = models.TimeField()
    event_end_time = models.TimeField()
    event_scheduled = models.BooleanField(default=True)

    def __str__(self):
        return self.event_title