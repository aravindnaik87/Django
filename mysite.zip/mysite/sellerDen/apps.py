from django.apps import AppConfig


class SellerdenConfig(AppConfig):
    name = 'sellerDen'
