from django.urls import path
from . import views
from django.conf import settings
from django.conf.urls.static import static
urlpatterns = [
    path('',views.wardrobe_welcome,name="wardrobeWelcome"),
    path('buy-product/<int:p_id>',views.buyProduct,name="buyProduct"),
    path('shop/<category>',views.shop,name="shop"),
    path('address/',views.address,name="address"),
    path('shop-brand/<str:brand>/<int:pageId>',views.shopBrand,name="shopBrand"),
    path('buy-brand-product/<str:itemcode>/',views.buyBrandProduct,name="buyBrand")
] + static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)