from django.db import models
from django.conf import settings
# Create your models here.

GENDER_CHOICES = (
    ("Men","Men"),
    ("Women","Women"),
    ("Boys","Boys"),
    ("Girls","Girls"),
    ("Unisex","Unisex")
)

FABRICS = (
    ("Cotton","Cotton"),
    ("Woolen","Woolen"),
    ("Silk","Silk"),
    ("Polyster","Polyster"),
    ("Satin","Satin"),
    ("Linen","Linen"),
    ("Chiffon","Chiffon"),
    ("Micro Polyster","Micro Polyster")
)

PACKSET = (
    ("Single","Single"),
    ("Two piece","Two piece"),
    ("Three piece","Three piece"),
)
NECKMODEL = (
    ("Polo","Polo"),
    ("Round","Round"),
    ("V-neck","V-neck"),
    ("Turtle","Turtle")
)

OUTFITMODEL = (
    ("T-shirt","T-shirt"),
    ("Shirt","Shirt"),
    ("Hoodie","Hoodie"),
    ("Sweat Shirt","Sweat Shirt"),
    ("Denim Jacket","Denim Jacket"),
    ("Bomber Jacket","Bomber Jacket"),
    ("Performance Tees","Performance Tees")
)

PATTERNS = (
    ("Printed","Printed"),
    ("Threaded","Threaded"),
    ("Hard print","Hard print")
)

SLEEVES = (
    ("Regular Sleeves","Regular Sleeves"),
    ("Half Sleeves","Half Sleeves"),
    ("Full Sleeves","Full Sleeves")
)

WASHCARE = (
    ("Machine Wash","Machine Wash"),
    ("Hand Wash","Hand Wash")
)

SIZE = (
    ("S","S"),
    ("M","M"),
    ("L","L"),
    ("XL","XL"),
    ("XXL","XXL"),
)

POPULARITY = (
    ("Luxury","Luxury"),
    ("Premium","Premium"),
    ("Featured","Featured"),
    ("Normal","Normal")
)

class Clothing_Details(models.Model):
    seller_ref_id = models.CharField(max_length=30,null=False)
    name = models.CharField(max_length=60,blank=False)
    brand = models.CharField(max_length=70)
    price = models.IntegerField(blank=False)
    shirt_model_type = models.CharField(max_length=50,choices=OUTFITMODEL)
    description = models.CharField(max_length=300)
    popularity = models.CharField(max_length=50,choices=POPULARITY)
    new_arrival = models.BooleanField(default=True)
    on_sale = models.BooleanField(default=False)
    s_quantity = models.IntegerField(blank=True)
    m_quantity = models.IntegerField(blank=True)
    l_quantity = models.IntegerField(blank=True)
    xl_quantity = models.IntegerField(blank=True)
    xxl_quantity = models.IntegerField(blank=True)
    category = models.CharField(choices=GENDER_CHOICES,max_length=30,blank=False)
    design_details = models.CharField(max_length=100)
    size_fit = models.CharField(max_length=100)
    material_care = models.CharField(max_length=100)
    fabric = models.CharField(max_length=100,choices=FABRICS)
    occasion = models.CharField(max_length=30)
    pack_set = models.CharField(max_length=30,choices=PACKSET)
    neck_model = models.CharField(max_length=20,choices=NECKMODEL)
    pattern = models.CharField(max_length=30,choices=PATTERNS)
    sleeves_length = models.CharField(max_length=30,choices=SLEEVES)
    Wash_care = models.CharField(max_length=30,choices=WASHCARE)
    img = models.ImageField(upload_to='profile_pictures',blank=True)
    demo_img = models.ImageField(upload_to='profile_pictures',blank=True)
    added_on = models.DateTimeField(auto_now_add=True)