from django.apps import AppConfig


class WardrobeConfig(AppConfig):
    name = 'wardrobe'
