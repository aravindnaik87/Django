from django.forms import ModelForm
from django import forms
from .models import Clothing_Details

class productsInformationForm(ModelForm):
    class Meta:
        model = Clothing_Details
        fields = ['name','brand','price','description','shirt_model_type','on_sale','popularity','new_arrival','s_quantity','m_quantity','l_quantity','xl_quantity','category','design_details','size_fit','material_care','fabric','occasion','pack_set','neck_model','pattern','sleeves_length','Wash_care','img','demo_img']
        widgets = {
            'name': forms.TextInput(attrs={'class': 'fields', 'placeholder' : 'Product Name'}),
            'brand': forms.TextInput(attrs={'class': 'fields', 'placeholder' : 'Forever 21, H&M, Jack & Jones etc.. '}),
            'description': forms.Textarea(attrs={'class': 'fields','rows' : '2', 'placeholder' : 'Product Description'}),
            'price': forms.NumberInput(attrs={'class': 'fields'}),
            'quantity': forms.NumberInput(attrs={'class': 'fields', 'placeholder' : 'No.of Units '}),
            'design_details': forms.TextInput(attrs={'class': 'fields', 'placeholder' : 'Design details'}),
            'size_fit': forms.TextInput(attrs={'class': 'fields', 'placeholder' : 'Fitting size'}),
            'material_care': forms.TextInput(attrs={'class': 'fields', 'placeholder' : 'Detergetn washable and dry details'}),
            'occasion': forms.TextInput(attrs={'class': 'fields', 'placeholder' : 'Casual, Party, Enthinic'}),
            's_quantity': forms.NumberInput(attrs={'class': 'fields'}),
            'm_quantity': forms.NumberInput(attrs={'class': 'fields'}),
            'l_quantity': forms.NumberInput(attrs={'class': 'fields'}),
            'xl_quantity': forms.NumberInput(attrs={'class': 'fields'}),
            'shirt_model_type': forms.TextInput(attrs={'class': 'fields'}),
            'on_sale': forms.CheckboxInput(attrs={'class':'checkbox-field'}),
            'popularity': forms.TextInput(attrs={'class': 'fields'}),
            'new_arrival': forms.CheckboxInput(attrs={'class':'checkbox-field'})
        }