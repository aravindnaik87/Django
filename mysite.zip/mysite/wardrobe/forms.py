from django.forms import ModelForm
from django import forms
from .models import Address

class addressForm(ModelForm):
    class Meta:
        model = Address
        fields = ["address_label","address_description","address_pincode","address_disctrict","address_state","address_default"]
        widgets = {
            'address_label': forms.TextInput(attrs={'class': 'fields', 'placeholder' : 'eg: Home, ofc etc..'}),
            'address_description': forms.Textarea(attrs={'class': 'fields', 'placeholder' : 'Street, area & locality ','rows':'3'}),
            'address_pincode': forms.TextInput(attrs={'class': 'fields', 'placeholder' : '000000'}),
            'address_disctrict': forms.TextInput(attrs={'class': 'fields', 'placeholder' : 'District Mandal'}),
            'address_state': forms.TextInput(attrs={'class': 'fields', 'placeholder' : 'Karnataka Delhi'}),
            'address_default': forms.CheckboxInput(attrs={'class':'radios'})
        }