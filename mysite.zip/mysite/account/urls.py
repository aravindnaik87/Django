from django.urls import path
from . import views

urlpatterns = [
    path('seller-login/',views.sellerLogin,name="sellerLogin"),
    path('login',views.customerLogin,name="customerLogin"),
    path('register',views.customerRegister,name="customerRegister"),
    path('seller-register',views.sellerRegister,name="sellerRegister")
]