from django.apps import AppConfig


class GrabroomConfig(AppConfig):
    name = 'grabRoom'
