function handledatetime() {
    var dateFormat = new Date()
    var pDate = document.getElementById('dateNow')
    var fTime = document.getElementById('fromTime')
    var tTime = document.getElementById('toTime')
    var calender = document.getElementById('calender')
    dateNow = String(dateFormat.getDate())
    yearNow = String(dateFormat.getFullYear())
    if(dateFormat.getMonth()+1 < 10) {
        var monthNow = "0" + String(dateFormat.getMonth()+1)
    } else {
        var monthNow = dateFormat.getMonth()+1
    }
    fullDateNow = yearNow+"-"+monthNow+"-"+dateNow
    pDate.value = fullDateNow
    pDate.setAttribute('meeting-date',dateNow)
    pDate.setAttribute('meeting-month',monthNow)
    pDate.setAttribute('meeting-year',yearNow)
    fTime.value = dateFormat.getHours()+":"+dateFormat.getMinutes()
    if (dateFormat.getHours() =="23") {
        tTime.value = "00"+":"+dateFormat.getMinutes()
    } else {
        tTime.value = dateFormat.getHours()+1+":"+dateFormat.getMinutes()
    }
    calender.addEventListener('submit',scheduleEvent)

}

function scheduleEvent(e) {
    e.preventDefault()
    var eventDateId = document.getElementById('dateNow')
    eventDate = eventDateId.value.slice(8)
    var a = document.getElementsByClassName('date-picker')
    for(var i=0;i<=a.length;i++) {
        if(a[i].getAttribute('data-date') == String(eventDate)) {
            a[i].classList.add('event-added')
            return
        }
    }
}