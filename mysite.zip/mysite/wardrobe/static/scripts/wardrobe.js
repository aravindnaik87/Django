function submitHandler(e) {
    e.preventDefault();
    $.ajax({
        type        : 'POST', // define the type of HTTP verb we want to use (POST for our form)
        url         : 'http://localhost:8000/wardrobe/address/', // the url where we want to POST
        data        : $('#addressForm').serialize(),
        dataType    : 'json', // what type of data do we expect back from the server
        success     : successFunction
    });
}

var addressSelected = document.getElementsByClassName('select-address-1');
for (var i=0;i<addressSelected.length;i++) {
    addressSelected[i].addEventListener('click',addressHandler)
}

function addressHandler(e) {
    var formAddress = document.getElementById('addressSelected')
    formAddress.value = this.value
}
function successFunction(data) {
    if(data.msg == "getAddress"){
        address = JSON.parse(data.addresses)
        obj = address[address.length-1]
        console.log(address)
        console.log(typeof(address))
        console.log(address.length)
        console.log(obj.fields.id)
        var addressBlock = document.createElement('div')
        addressBlock.setAttribute('class','address-block')
        var label = document.createElement('p')
        label.setAttribute('class','address-label')
        label.textContent = obj.fields.address_label
        var fullAddress = document.createElement('p')
        fullAddress.textContent = "Address: "+obj.fields.address_description
        var pincode = document.createElement('p')
        pincode.textContent = "Pincode "+obj.fields.address_pincode
        var district = document.createElement('p')
        district.textContent = "District "+obj.fields.address_disctrict
        var state = document.createElement('p')
        state.textContent = "State: "+ obj.fields.address_state
        var addressradio = document.createElement('input')
        addressradio.setAttribute('type','radio')
        addressradio.setAttribute('class','select-address-1')
        addressradio.setAttribute('name','select-address')
        addressradio.setAttribute('value',obj.pk)
        addressradio.addEventListener('click',addressHandler)
        addressBlock.appendChild(label)
        addressBlock.appendChild(fullAddress)
        addressBlock.appendChild(pincode)
        addressBlock.appendChild(district)
        addressBlock.appendChild(state)
        addressBlock.appendChild(addressradio)
        var parent = document.getElementsByClassName('select-address')[0]
        parent.appendChild(addressBlock)
        document.getElementById('addressForm').reset()
        toggleAddAddress()
    }
}

//size selection
var element = document.getElementsByClassName('size-info');
if (element.length != 0) {
    for(var i=0;i<=element.length;i++){
        element[i].addEventListener('click',function(i){
            var id = this.getAttribute('id')
            var size_element = document.getElementById(id)
            if(!size_element.classList.contains('active')){
                size_element.classList.add('active')
                var size_input = document.getElementById('selected_size')
                size_input.value = id
                check_selected_sizes(id)
            }


        })
    }
}



function check_selected_sizes(id) {
    for(var i=0;i<element.length;i++){
        var already_selected_sizes = element[i].getAttribute('id')
        if(already_selected_sizes!=id){
            if(document.getElementById(already_selected_sizes).classList.contains('active')){
                document.getElementById(already_selected_sizes).classList.remove('active')
            }
        }
    }
}

function userProfileAction() {
    var id = document.getElementsByClassName('profile-actions')[0];
    if(id.classList.contains('hide')){
        id.classList.remove('hide')
    } else {
        id.classList.add('hide')
    }
}

function criteria(event) {
    var search = document.getElementById('search').value
    if (search.length > 0 && event.keyCode != 8  )  {
        if(search != ""){
            $.ajax({
                type: "GET",
                url: window.location.pathname,
                data: {
                    query : $('#search').val()
                },
                dataType: "json",
                success: function (data) {
                    resp = JSON.parse(data.search_result)
                    var search = document.getElementsByClassName('search-suggestions')[0]
                    if(search.childElementCount>0){
                        console.log("remove children and add again")
                        for(var i=0;i<=search.childElementCount;i++){
                            search.children[0].remove()
                        }
                        for(var i=0;i<resp.length;i++){
                            var ul = document.createElement('ul')
                            var li = document.createElement('li')
                            var a = document.createElement('a')
                            var p = document.createElement('p')
                            var category = document.createElement('a')
                            category.setAttribute('href','javascript:void(0)')
                            href = "/wardrobe/buy-product/"+resp[i].pk
                            a.setAttribute("href",href)
                            ul.appendChild(li)
                            a.textContent = resp[i].fields.name
                            li.appendChild(a)
                            search.appendChild(ul)
                            p.setAttribute('class','search-category')
                            p.textContent = "available in "
                            category.textContent = resp[i].fields.category
                            p.appendChild(category)
                            li.appendChild(p)
                        }
                    } else {
                        for(var i=0;i<resp.length;i++){
                            var ul = document.createElement('ul')
                            var li = document.createElement('li')
                            var a = document.createElement('a')
                            var p = document.createElement('p')
                            var category = document.createElement('a')
                            category.setAttribute('href','javascript:void(0)')
                            href = "/wardrobe/buy-product/"+resp[i].pk
                            a.setAttribute("href",href)
                            ul.appendChild(li)
                            a.textContent = resp[i].fields.name
                            li.appendChild(a)
                            search.appendChild(ul)
                            p.setAttribute('class','search-category')
                            p.textContent = "available in "
                            category.textContent = resp[i].fields.category
                            p.appendChild(category)
                            li.appendChild(p)
                        }
                    }
                },
                error: function (error) {
                    console.log(error)
                }
            });
        } else {
            var suggestion = document.getElementsByClassName('search-suggestions')[0]
            for(var i =0;i<=suggestion.childElementCount;i++){
                suggestion.children[0].remove()
            }
        }
    }
}

//add to cart
function addToCart(prod_id,cust_id,e){
    if(localStorage.getItem('cartDetails')) {
        obj = JSON.parse(localStorage.getItem('cartDetails'))
        var index = obj.prod_id.indexOf(prod_id)
        if(index<0) {
            obj.prod_id.push(prod_id)
            setStorage(obj)
            console.log(obj)
        }
    } else {
    console.log('no session')
        prodId = []
        prodId.push(prod_id)
        addedProd = {
            "customerId":  cust_id,
            "prod_id": prodId
        }
        setStorage(addedProd)
    }
}
function setStorage(addedProd){
    var storage = localStorage.setItem('cartDetails',JSON.stringify(addedProd))
    var cartCount = document.getElementById('cart-count')
    var cartvalue = JSON.parse(localStorage.getItem('cartDetails')).prod_id.length
    cartCount.innerText = cartvalue
    console.log(storage)
    $.ajax({
        type: "POST",
        data: localStorage.getItem('cartDetails'),
        url: window.location.pathname,
        dataType: 'json',
        success: function(data){
            console.log("ajax")
        },
        error: function(jqXHR, textStatus, errorThrown) {
            console.log(jqXHR);
        }
    });
    console.log(JSON.parse(localStorage.getItem('cartDetails')))
}

//Buy Product page update cart value based on the quantity

function updateCartPrice(price) {
    var quantity = document.getElementById('quantity')
    productQuantity = Number(quantity.value)
    updatedProductPrice = productQuantity*price
    var price = document.getElementById('productPrice')
    price.innerText = updatedProductPrice

}

function toggleAddAddress() {
    var a = document.getElementById('addAddress')
    if(a.classList.contains('hide')) {
        a.classList.remove('hide')
    } else {
        a.classList.add('hide')
    }
}



function placeOrder(e) {
    e.preventDefault();
    var addressCheck = document.getElementsByClassName('select-address-1');
    var checkedAddress;
    for(var i=0;i<addressCheck.length;i++) {
        if(addressCheck[i].checked) {
            checkedAddress = addressCheck[i].value;
                return;
         }
    }
        console.log(checkedAddress)
        alert('hi')
}