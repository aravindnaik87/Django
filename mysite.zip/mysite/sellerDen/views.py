from django.shortcuts import render,HttpResponse
from .forms import productsInformationForm
from .models import Clothing_Details
# Create your views here.

def dashboard(request):
    form = productsInformationForm()
    if request.method == "GET":
        products_details = Clothing_Details.objects.filter(seller_ref_id=request.user.id)
        if products_details:
            print(request.user.id)
            return  render(request,'default/dashboard.html',{'form':form,'products':products_details})
        return  render(request,'default/dashboard.html',{'form':form})
    else:
        form = productsInformationForm(request.POST, request.FILES)
        if form.is_valid():
            print("valid")
            products_details = form.save(commit=False)
            products_details.seller_ref_id = request.user.id
            products_details.save()
            products_details = Clothing_Details.objects.filter(seller_ref_id=request.user.id)
        return render(request,'default/dashboard.html',{'form':form,'products':products_details})
