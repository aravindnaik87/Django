import json
import requests
from django.http import JsonResponse
from django.shortcuts import render, redirect
from django.core import serializers
from django.db.models import Q
from django.views.decorators.csrf import csrf_exempt
from django.core import serializers
from sellerDen.models import Clothing_Details
from adminDen.models import BrandsModel
from account.models import Account
from .models import Address
from .forms import addressForm
# Create your views here.

class Search:
    def query_result(request):
        if request.is_ajax():
            resp = request.GET["query"]
            print("!@#$%^&*()resp",resp)
            print("!@#$%^&*()typeresp",type(resp))
            query_result = Clothing_Details.objects.filter(Q(name__icontains=resp))
            product_id=[]
            for product in query_result:
                print(product.pk)
                product_id.append(product.pk)
            print("!@#$%^&*()",product_id)
            print("!@#$%^&*()",query_result)
            Serialized_query_result = serializers.serialize("json",Clothing_Details.objects.filter(Q(name__icontains=resp)))
            return Serialized_query_result

@csrf_exempt
def wardrobe_welcome(request):
    print(request.user)
    if request.is_ajax():
        response = Search.query_result(request)
        return JsonResponse({
            "search_result": response
        })
    if request.method == "GET":
        products = Clothing_Details.objects.all()
        return render(request,'default/welcome.html',{'products':products})
    else:
        if request.is_ajax():
            cartDetails = json.loads(request.body)
            sessionCustomerId = cartDetails["customerId"]
            ProductId = cartDetails["prod_id"]
            request.session["sessionProductId"] = ProductId
            cartCount = len(cartDetails["prod_id"])
            request.session["sessioncartCount"] = cartCount
            print("sessioncartCount",request.session.get('sessioncartCount'))
        return render(request,'default/welcome.html',{"cartCount":cartCount})

def buyProduct(request,p_id):
    if request.method == "GET":
        getProductDetails = Clothing_Details.objects.get(id=p_id)
        seller_details = Account.objects.get(id=getProductDetails.seller_ref_id)
        userDetails = Account.objects.get(id=request.user.id)
        if request.is_ajax():
            response = Search.query_result(request)
            return JsonResponse({
                "search_result": response
            })
        return render(request,'default/buy-product.html',{'seller_details':seller_details,'ProductBrief':getProductDetails,'userDetails':userDetails })
    else:
        if request.method == "POST":
            product_id = p_id
            selected_size = request.POST["selected_size"]
            customer_id = request.user.id
            order_obj = {
                "product" : product_id,
                "size": selected_size,
                "customer": customer_id
            }
            request.session["order"] = order_obj
            print(request.session.get('order'))
            getProductDetails = Clothing_Details.objects.get(id=p_id)
            seller_details = Account.objects.get(id=getProductDetails.seller_ref_id)
            userDetails = Account.objects.get(id=request.user.id)
            return redirect('address')

def address(request):
    getAddress = Address.objects.filter(customer_id = request.user.id)
    print(getAddress)
    order_details = request.session.get('order')
    print(order_details)
    product_id = order_details['product']
    order = Clothing_Details.objects.get(id = product_id)
    delivery_charges = int(99)
    product_final_price = int(order.price)+delivery_charges
    if request.is_ajax():
        response = Search.query_result(request)
        return JsonResponse({
            "search_result": response
        })
    if request.method == "GET":
        form = addressForm()
        return  render(request,'default/address.html',{'form':form,'getAddress':getAddress,'order':order,'product_final_price':product_final_price})
    else:
        form = addressForm(request.POST)
        if form.is_valid():
            response = form.save(commit=False)
            response.customer_id = request.user.id
            response.save()
            customerId = request.user.id
            deliverycharges = int(99)
            getAddress = serializers.serialize("json",Address.objects.filter(customer_id = request.user.id))
            if getAddress:
                return JsonResponse({
                    'msg': "getAddress",
                    'addresses': getAddress
                })
        print("!@#$%^&*)",order.seller_ref_id)
        order_place_obj = {
            "customer_id": request.user.id,
            "product_id": product_id,
            "address_id": request.POST["orderAddress"],
            "seller_id": order.seller_ref_id,
            "brand": order.brand
        }
        print("!@#$%^&*()QWERTYUIOP",order_place_obj)
        return render(request,'default/address.html',{'form':form,'getAddress':getAddress,'order':order,'product_final_price':product_final_price})

def shop(request,category):
    if request.method == "GET":
        categories = Clothing_Details.objects.filter(category=category.capitalize())
        print(categories)
        brands = BrandsModel.objects.all()
        return render(request,'default/shop.html',{'categories':categories,'brands':brands})

def shopBrand(request,brand,pageId):
    if request.method == "GET":
        url = "https://apidojo-hm-hennes-mauritz-v1.p.rapidapi.com/products/list"
        querystring = {"categories":"men_all","sortBy":"stock","concepts":"H%26M MAN","country":"in","lang":"en","currentpage":pageId,"pagesize":"30"}
        headers = {
            'x-rapidapi-host': "apidojo-hm-hennes-mauritz-v1.p.rapidapi.com",
            'x-rapidapi-key': "e6f3845a6cmshe801323dc8537c5p1dff6ajsndb17154b50f2"
        }
        response = requests.request("GET", url, headers=headers, params=querystring).json()
        print(response)
        return render(request,'default/shop-brand.html',{'response':response})

def buyBrandProduct(request,itemcode):
    if request.method == "GET":
        url = "https://apidojo-hm-hennes-mauritz-v1.p.rapidapi.com/products/detail"
        querystring = {"country":"in","lang":"en","productcode":itemcode}
        headers = {
            'x-rapidapi-host': "apidojo-hm-hennes-mauritz-v1.p.rapidapi.com",
            'x-rapidapi-key': "e6f3845a6cmshe801323dc8537c5p1dff6ajsndb17154b50f2"
        }

        response = requests.request("GET", url, headers=headers, params=querystring).json()

        print(response)

        return render(request,'default/buy-brand-product.html',{'response':response})