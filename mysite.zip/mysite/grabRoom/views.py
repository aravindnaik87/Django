from django.shortcuts import render,HttpResponse

# Create your views here.

def calenderData(request):
    return render(request,'default/room.html')