from passlib.hash import pbkdf2_sha256
from django.shortcuts import render,redirect
from django.contrib.auth import  authenticate,login
from .forms import accountCustomerRegister,accountSellerRegister
from .models import Account
# Create your views here.

def sellerLogin(request):
    form = accountSellerRegister()
    if request.method == "POST":
        form = accountSellerRegister(request.POST)
        email = request.POST["email"]
        requestUser = Account.objects.get(email=email)
        if requestUser:
            password = request.POST["password"]
            passwordVerify = pbkdf2_sha256.verify(password,requestUser.password)
            if passwordVerify:
                login(request,requestUser)
                return redirect('sellerDashboard')
        else:
            return render(request,'registration/seller-login.html')
    else:
        return render(request,'registration/seller-login.html')

def customerLogin(request):
    print("!@#$%^&*()",Account.objects.all())
    if request.method == "POST":
        email = request.POST["customer_email"]
        password = request.POST["customer_password"]
        user = Account.objects.get(email = email)
        password_verify = pbkdf2_sha256.verify(password,user.password)
        if password_verify:
            authenticate(request,email = email,password=user.password)
            if user is not None:
                login(request,user)
                return redirect('wardrobeWelcome')
        else:
            return render(request,'registration/customer-login.html')
    else:
        return render(request,'registration/customer-login.html')

def customerRegister(request):
    form = accountCustomerRegister()
    is_customer = True
    if request.method == "POST":
        form = accountCustomerRegister(request.POST)
        req_email = request.POST["email"]
        password = request.POST["password"]
        if form.is_valid():
            reqDetails = form.save(commit=False)
            reqDetails.is_customer = is_customer
            reqDetails.password = pbkdf2_sha256.hash(password)
            print(reqDetails.password)
            reqDetails.save()
            user = Account.objects.get(email = req_email)
            password_verify = pbkdf2_sha256.verify(password,reqDetails.password)
            if password_verify:
                authenticate(request,email = req_email,username= request.POST["username"],password=reqDetails.password)
                if user is not None:
                    login(request,user)
                    return redirect('wardrobeWelcome')
                else:
                    return render(request,'registration/customer-register.html')
        else:
            error = "Something went wrong..."
            return render(request,'registration/customer-register.html',{'form':form,'error':error})
    else:
        return render(request,'registration/customer-register.html',{'form':form})

def sellerRegister(request):
    form = accountSellerRegister()
    is_seller = True
    if request.method == "POST":
        form = accountSellerRegister(request.POST)
        req_email = request.POST["email"]
        password = request.POST["password"]
        if form.is_valid():
            reqDetails = form.save(commit=False)
            reqDetails.is_seller = is_seller
            reqDetails.password = pbkdf2_sha256.hash(password)
            print(reqDetails.password)
            reqDetails.save()
            user = Account.objects.get(email = req_email)
            password_verify = pbkdf2_sha256.verify(password,reqDetails.password)
            if password_verify:
                authenticate(request,email = req_email,username= request.POST["username"],password=reqDetails.password)
                if user is not None:
                    login(request,user)
                    return redirect('sellerDashboard')
                else:
                    return render(request,'registration/seller-register.html')
    else:
        return render(request,'registration/seller-register.html',{'form':form})