from django.shortcuts import render
from .forms import BrandsModelForm
from .models import BrandsModel
# Create your views here.

def addBrands(request):
    if request.method == "POST":
        form = BrandsModelForm(request.POST,request.FILES)
        if form.is_valid():
            form.save()
            print(BrandsModel.objects.all())
        return render(request,'default/brands.html',{'form':form})
    else:
        form = BrandsModelForm()
        return render(request,'default/brands.html',{'form':form})