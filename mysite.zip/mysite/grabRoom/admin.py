from django.contrib import admin
from .models import DetailedEvent
# Register your models here.

admin.site.register(DetailedEvent)