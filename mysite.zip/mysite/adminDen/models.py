from django.db import models

# Create your models here.

BRANDCATEGORY = (
    ("Men","Men"),
    ("Women","Women"),
    ("Boys","Boys"),
    ("Girls","Girls"),
    ("Unisex","Unisex"),
    ("All","All")
)

class BrandsModel(models.Model):
    brand_name = models.CharField(max_length=60,unique=True)
    brand_description = models.CharField(max_length=200)
    brand_category = models.CharField(max_length=30,choices=BRANDCATEGORY)
    brand_verified = models.BooleanField(default=False)
    brand_img = models.ImageField(upload_to='brand_pics',blank=True)

    def __str__(self):
        return self.brand_name