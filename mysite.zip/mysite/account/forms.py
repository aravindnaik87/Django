from django.forms import ModelForm
from django import forms
from .models import Account

class accountSellerRegister(ModelForm):
    class Meta:
        model = Account
        fields = ['email','username','company_name','industry_name','password']
        widgets = {
            'email': forms.EmailInput(attrs={'class': 'fields', 'placeholder' : 'abc@xyz.com'}),
            'username': forms.TextInput(attrs={'class': 'fields', 'placeholder' : 'abcdef123'}),
            'password': forms.PasswordInput(attrs={'class': 'fields', 'placeholder' : 'abcdef123'}),
            'company_name': forms.Textarea(attrs={'class': 'fields', 'placeholder' : 'Company Name', 'rows':'1'})
        }

class accountCustomerRegister(ModelForm):
    class Meta:
        model = Account
        fields = ['email','username']
        widgets = {
            'email': forms.EmailInput(attrs={'class': 'fields', 'placeholder' : 'abc@xyz.com'}),
            'username': forms.TextInput(attrs={'class': 'fields', 'placeholder' : 'abcdef123'})
        }